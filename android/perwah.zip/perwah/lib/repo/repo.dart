import 'package:http/http.dart' as http;
import 'package:perwha/model/ChargeAreaDetails.dart';
import 'package:perwha/model/JobDetails.dart';
import 'package:perwha/model/PermitDocuments.dart';
import 'package:perwha/model/PhotographDetail.dart';
import 'package:perwha/model/ProfileDetails.dart';
import 'dart:async';
import 'dart:convert';

import '../model/PermitResponse.dart';
import '../model/login_response.dart';

// APi Call kiti login details lai
Future<LoginResponse> makeRequest(
    String url, String username, String password) async {
  final loginResponse = await http.post(Uri.parse(url),
      headers: {
        //authorization: bearer
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(
          <String, String>{'username': username, 'password': password}));

  if (loginResponse.statusCode == 200) {
    var data = jsonDecode(loginResponse.body.toString());
    print(data);
    return LoginResponse.fromJson(jsonDecode(loginResponse.body));
  } else {
    throw Exception('Failed to post user.');
  }
}

//api call krrni permit details
Future<PermitResponse> getPermitDetails() async {
  final permitResponse = await http
      .post(Uri.parse('http://mngl.intileo.com/api/getPermitdetail'), headers: {
    'authorization':
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
    'Content-Type': 'application/json; charset=UTF-8',
  });
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print(data);
    return PermitResponse.fromJson(jsonDecode(permitResponse.body));
  } else {
    throw Exception('Failed to get Permits');
  }
}

Future<ProfileDetails> getProfileDetails() async {
  final permitResponse = await http
      .get(Uri.parse('http://mngl.intileo.com/api/profile'), headers: {
    'authorization':
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
    'Content-Type': 'application/json; charset=UTF-8',
  });
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print(data);
    return ProfileDetails.fromJson(jsonDecode(permitResponse.body));
  } else {
    throw Exception('Failed to get Permits');
  }
}

Future<JobDetails> getPermit() async {
  final permitResponse = await http
      .get(Uri.parse('http://mngl.intileo.com/api/joblist'), headers: {
    'authorization':
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
    'Content-Type': 'application/json; charset=UTF-8',
  });
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print("getPermitResponse====$data");
    return JobDetails.fromJson(jsonDecode(permitResponse.body));
  } else {
    throw Exception('Failed to get Permits');
  }
}

Future<PhotographDetail> getPhotoGraphDetails() async {
  final permitResponse = await http
      .get(Uri.parse('http://mngl.intileo.com/api/getphotographs'), headers: {
    'authorization':
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
    'Content-Type': 'application/json; charset=UTF-8',
  });
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print(data);
    return PhotographDetail.fromJson(jsonDecode(permitResponse.body));
  } else {
    throw Exception('Failed to get Permits');
  }
}

Future<ChargeAreaDetails> getChargeArea() async {
  final permitResponse = await http.post(
      Uri.parse('http://mngl.intileo.com/api/getChargeareabyPAId'),
      headers: {
        'authorization':
            "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{"project_area_id": "3"}));
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print(data);
    return ChargeAreaDetails.fromJson(jsonDecode(permitResponse.body));
  } else {
    throw Exception('Failed to get Permits');
  }
}

Future<String> UploadPermitDetails() async {
  final permitResponse = await http
      .get(Uri.parse("http://mngl.intileo.com/api/uploadPermitDetails"), headers: {
    'authorization':
    "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
    'Content-Type': 'application/json; charset=UTF-8',
  });
  if (permitResponse.statusCode == 200) {
    var data = jsonDecode(permitResponse.body.toString());
    print(data);
    return "null";
  } else {
    throw Exception('Failed to get Permits');
  }
}
Future<PermitDocuments> getdocumentbypermitid(
    String id) async {
  final Uploaddocuments = await http.post(Uri.parse("http://mngl.intileo.com/api/documentbypermitid"),
      headers: {
        'authorization':
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiN2Q0ZDcwYzZhZTAyYjllMGZkMGMwMGRhOTg2NGE5ZTIwOGE4ZDUxMjY2NDIyYzM0MDQ2MTdlY2RhYmMwYjNhODEyYzVjOTI0MmJmNGQwNjciLCJpYXQiOjE2NjUxMjE1MzcuNjQyMjUwMDYxMDM1MTU2MjUsIm5iZiI6MTY2NTEyMTUzNy42NDIyNTY5NzUxNzM5NTAxOTUzMTI1LCJleHAiOjE2ODA4NDYzMzcuNDA4ODE3MDUyODQxMTg2NTIzNDM3NSwic3ViIjoiMiIsInNjb3BlcyI6W119.bS1vIdPm1ZVhD4X7l3QqI9M2TIZxMNtEHwZ7XEqX_Sl8e0p0s2yhs-CRBomw9LAe62of50exu70PdpTrmshjqYoHS02DVg1uuGqdycwhbjYwD9B9Fn5g3h5fD_jq0rq4cLOfay7swCsEumqYU2YLMn2DTSL4BZ8S6wHMTy9zBKGdKjKdkQmcPPUjmqU9Ab3Pw_ev8Z15cD5QdMwEKjJ3fWs_ShFhi20TXOxQh81iEvaA23mJE0Dam5K-A2KTJGGX7yTQBAPuPLgER2qBW2eo47Hi_QMIQXFYEsVBHn0UcyWN6fcyt-pe5hWN7TSCq7e5h9DQSW46y3LmhPgR4KvPzXT1lVVvyPRtKuBEqIABGKO-RX8LqstNbeKg1cCsPLyRqi5wKWdiq8bMBM2mixA_PjsnjvR2t9crFYRX6tBag30EhaidFu8gyx23ylYBUhVT0MC5SJtVJdgN1E0e0yxGIzQ8lVvlBUumbzZJn4N2ynUpQW7KoDuANOAecwXDjAzvQI1N_egP5tJLj0Fn7cTeLN5K4TFuuC2PVZq3TcajVRcfKIGF3dQ9KvUzEnAVOjvxdbyTPcjuQITB7mZ0IW31Wv4Rf1Z6JEdpzmIbDSl_0bvjNCfQ4pN4wQaSAFF-grKsJLx_9OYkiKZhrSz38ieIAXN8hS5F-tm7-s-PUM7y7J8",
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(
          <String, String>{'permit_id': id}));
print(id);
  if (Uploaddocuments.statusCode == 200) {
    var data = jsonDecode(Uploaddocuments.body.toString());
    print(data);
    return PermitDocuments.fromJson(jsonDecode(Uploaddocuments.body));
  } else {
    throw Exception('Failed to post user.');
  }
}