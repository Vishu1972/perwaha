import 'dart:core';

import 'package:intl/intl.dart';

String dateFormater(String date){
  var formatedDate =  DateFormat("dd-MM-yyyy h:mm a").format(DateTime.parse(date));
  return formatedDate;
}