class LoginResponse {
  bool? status;
  String? token;
  String? msg;
  String? designation;

  LoginResponse({this.status, this.token, this.msg, this.designation});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    if (json["status"] is bool) {
      status = json["status"];
    }
    if (json["token"] is String) {
      token = json["token"];
    }
    if (json["msg"] is String) {
      msg = json["msg"];
    }
    if (json["designation"] is String) {
      msg = json["designation"];
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    _data["token"] = token;
    _data["msg"] = msg;
    _data["designation"] = designation;
    return _data;
  }
}