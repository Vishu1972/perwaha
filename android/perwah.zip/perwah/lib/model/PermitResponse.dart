import 'PermitDetails.dart';

class PermitResponse {

  PermitResponse({
      required this.status,
      required this.approved,
      required this.pending,
      required this.rejected,
      required this.live,
      required this.closureApplied,
      required this.closed,
      required this.suspended,
      required this.total,
      required this.count,
      required this.permitDetails,});

  PermitResponse.fromJson(dynamic json) {
    status = json['status'];
    approved = json['approved'];
    pending = json['pending'];
    rejected = json['rejected'];
    live = json['live'];
    closureApplied = json['closure_applied'];
    closed = json['closed'];
    suspended = json['suspended'];
    total = json['total'];
    count = json['count'];
    if (json['permitDetails'] != null) {
      permitDetails = [];
      json['permitDetails'].forEach((v) {
        permitDetails!.add(PermitDetails.fromJson(v));
      });
    }
  }
  bool? status;
  int? approved;
  int? pending;
  int? rejected;
  int? live;
  int? closureApplied;
  int? closed;
  int? suspended;
  int? total;
  int? count;
  List<PermitDetails>? permitDetails;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['approved'] = approved;
    map['pending'] = pending;
    map['rejected'] = rejected;
    map['live'] = live;
    map['closure_applied'] = closureApplied;
    map['closed'] = closed;
    map['suspended'] = suspended;
    map['total'] = total;
    map['count'] = count;
    if (permitDetails != null) {
      map['permitDetails'] = permitDetails!.map((v) => v.toJson()).toList();
    }
    return map;
  }

}