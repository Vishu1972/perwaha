/// status : true
/// data : {"name":"TPE","email":"tpe@gmail.com","mobile":"9898989898","designation":"TPE","state":"Himachal","geo_area":"UNA","project_area":[{"description":"Pa 1"}],"charge_area":[{"description":"DEMO AREA"}],"profile_photo":""}

class ProfileDetails {
  ProfileDetails({
      bool? status, 
      Data? data,}){
    _status = status;
    _data = data;
}

  ProfileDetails.fromJson(dynamic json) {
    _status = json['status'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }
  bool? _status;
  Data? _data;
ProfileDetails copyWith({  bool? status,
  Data? data,
}) => ProfileDetails(  status: status ?? _status,
  data: data ?? _data,
);
  bool? get status => _status;
  Data? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.toJson();
    }
    return map;
  }

}

/// name : "TPE"
/// email : "tpe@gmail.com"
/// mobile : "9898989898"
/// designation : "TPE"
/// state : "Himachal"
/// geo_area : "UNA"
/// project_area : [{"description":"Pa 1"}]
/// charge_area : [{"description":"DEMO AREA"}]
/// profile_photo : ""

class Data {
  Data({
      String? name, 
      String? email, 
      String? mobile, 
      String? designation, 
      String? state, 
      String? geoArea, 
      List<ProjectArea>? projectArea, 
      List<ChargeArea>? chargeArea, 
      String? profilePhoto,}){
    _name = name;
    _email = email;
    _mobile = mobile;
    _designation = designation;
    _state = state;
    _geoArea = geoArea;
    _projectArea = projectArea;
    _chargeArea = chargeArea;
    _profilePhoto = profilePhoto;
}

  Data.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _mobile = json['mobile'];
    _designation = json['designation'];
    _state = json['state'];
    _geoArea = json['geo_area'];
    if (json['project_area'] != null) {
      _projectArea = [];
      json['project_area'].forEach((v) {
        _projectArea?.add(ProjectArea.fromJson(v));
      });
    }
    if (json['charge_area'] != null) {
      _chargeArea = [];
      json['charge_area'].forEach((v) {
        _chargeArea?.add(ChargeArea.fromJson(v));
      });
    }
    _profilePhoto = json['profile_photo'];
  }
  String? _name;
  String? _email;
  String? _mobile;
  String? _designation;
  String? _state;
  String? _geoArea;
  List<ProjectArea>? _projectArea;
  List<ChargeArea>? _chargeArea;
  String? _profilePhoto;
Data copyWith({  String? name,
  String? email,
  String? mobile,
  String? designation,
  String? state,
  String? geoArea,
  List<ProjectArea>? projectArea,
  List<ChargeArea>? chargeArea,
  String? profilePhoto,
}) => Data(  name: name ?? _name,
  email: email ?? _email,
  mobile: mobile ?? _mobile,
  designation: designation ?? _designation,
  state: state ?? _state,
  geoArea: geoArea ?? _geoArea,
  projectArea: projectArea ?? _projectArea,
  chargeArea: chargeArea ?? _chargeArea,
  profilePhoto: profilePhoto ?? _profilePhoto,
);
  String? get name => _name;
  String? get email => _email;
  String? get mobile => _mobile;
  String? get designation => _designation;
  String? get state => _state;
  String? get geoArea => _geoArea;
  List<ProjectArea>? get projectArea => _projectArea;
  List<ChargeArea>? get chargeArea => _chargeArea;
  String? get profilePhoto => _profilePhoto;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['mobile'] = _mobile;
    map['designation'] = _designation;
    map['state'] = _state;
    map['geo_area'] = _geoArea;
    if (_projectArea != null) {
      map['project_area'] = _projectArea?.map((v) => v.toJson()).toList();
    }
    if (_chargeArea != null) {
      map['charge_area'] = _chargeArea?.map((v) => v.toJson()).toList();
    }
    map['profile_photo'] = _profilePhoto;
    return map;
  }

}

/// description : "DEMO AREA"

class ChargeArea {
  ChargeArea({
      String? description,}){
    _description = description;
}

  ChargeArea.fromJson(dynamic json) {
    _description = json['description'];
  }
  String? _description;
ChargeArea copyWith({  String? description,
}) => ChargeArea(  description: description ?? _description,
);
  String? get description => _description;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['description'] = _description;
    return map;
  }

}

/// description : "Pa 1"

class ProjectArea {
  ProjectArea({
      String? description,}){
    _description = description;
}

  ProjectArea.fromJson(dynamic json) {
    _description = json['description'];
  }
  String? _description;
ProjectArea copyWith({  String? description,
}) => ProjectArea(  description: description ?? _description,
);
  String? get description => _description;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['description'] = _description;
    return map;
  }

}