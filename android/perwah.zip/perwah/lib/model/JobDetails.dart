/// status : true
/// data : [{"id":1,"description":"Test1"}]

class JobDetails {
  JobDetails({
      bool? status, 
      List<Data>? data,}){
    _status = status;
    _data = data;
}

  JobDetails.fromJson(dynamic json) {
    _status = json['status'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(Data.fromJson(v));
      });
    }
  }
  bool? _status;
  List<Data>? _data;
JobDetails copyWith({  bool? status,
  List<Data>? data,
}) => JobDetails(  status: status ?? _status,
  data: data ?? _data,
);
  bool? get status => _status;
  List<Data>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 1
/// description : "Test1"

class Data {
  Data({
      num? id, 
      String? description,}){
    _id = id;
    _description = description;
}

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _description = json['description'];
  }
  num? _id;
  String? _description;
Data copyWith({  num? id,
  String? description,
}) => Data(  id: id ?? _id,
  description: description ?? _description,
);
  num? get id => _id;
  String? get description => _description;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['description'] = _description;
    return map;
  }

}