class PermitDetails {

  PermitDetails({
      required this.id,
      required this.locality,
      required this.building,
      required this.status,
      required this.jobDecs,
      required this.statusTime,
      required this.createTime,});

  PermitDetails.fromJson(dynamic json) {
    id = json['id'];
    locality = json['locality'];
    building = json['building'];
    status = json['status'];
    jobDecs = json['job_decs'];
    statusTime = json['status_time'];
    createTime = json['create_time'];
  }
  int? id;
  String? locality;
  String? building;
  String? status;
  String? jobDecs;
  String? statusTime;
  String? createTime;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['locality'] = locality;
    map['building'] = building;
    map['status'] = status;
    map['job_decs'] = jobDecs;
    map['status_time'] = statusTime;
    map['create_time'] = createTime;
    return map;
  }

}