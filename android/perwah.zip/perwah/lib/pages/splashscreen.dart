import 'dart:async';

import 'package:flutter/material.dart';
import 'package:perwha/pages/homepage.dart';
import 'package:perwha/pages/loginpage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late SharedPreferences sharedPreferences;
  bool isLogin = false;

  _showSavedValue() async {
    sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setBool('boolValue', true);
    setState(() {
      // doubt
      print(sharedPreferences.getBool("is_Login")!);
      isLogin = sharedPreferences.getBool("is_Login")!;
    });
  }

  @override
  void initState() {
    _showSavedValue();
    Timer(Duration(seconds: 2), (() {
      if (isLogin) {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => HomePage()));
      } else {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => LoginPage()));
      }
    }));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Image.asset(
              'assets/images/mngl_1.png',
              height: 104,
              width: 104,
            ),
            Text(
              'PerWAH',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 32),
            ),
          ]),
        ),
      ),
    );
  }
}
