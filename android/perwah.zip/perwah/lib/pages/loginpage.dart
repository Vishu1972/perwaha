import 'package:flutter/material.dart';
import 'package:perwha/model/login_response.dart';
import 'package:perwha/repo/repo.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'homepage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginpageState();
}

class _LoginpageState extends State<LoginPage> {
  String url = "http://mngl.intileo.com/api/login";
  bool login = false;
  bool _isVisible = false;
  late SharedPreferences sharedPreferences;
  TextEditingController usernameControler = TextEditingController();
  TextEditingController passwordControler = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Positioned(
                            child: Image.asset(
                              'assets/images/rec.png',
                              fit: BoxFit.fitWidth,
                            ),
                          ),
                          Positioned(
                            left: MediaQuery.of(context).size.width * .5 - 52,
                            top: 80,
                            child: Image.asset(
                              'assets/images/mngl_1.png',
                              height: 104,
                              width: 104,
                            ),
                          ),
                          const SizedBox(
                            height: 1,
                          ),
                          Positioned(
                            top: 184,
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 33,
                              child: const Text(
                                'PerWAH',
                                textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 32),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 326,
                            child: TextField(
                              controller: usernameControler,
                              decoration: const InputDecoration(
                                filled: true,
                                focusColor: Colors.white,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(),
                                hintText: 'Enter User ID',
                                labelText: 'User ID',
                              ),
                              style: const TextStyle(
                                fontSize: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 30.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 326,
                            child: TextField(
                              controller: passwordControler,
                              obscureText: true,
                              decoration: const InputDecoration(
                                filled: true,
                                focusColor: Colors.white,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(),
                                hintText: 'Enter Password',
                                labelText: 'Password',
                              ),
                              style: const TextStyle(fontSize: 20),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 37.0,
                            width: 326,
                            child: ElevatedButton(
                              onPressed: (() {
                                setState(() {
                                  login = true;
                                });
                              }),
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.orange),
                              child: const Text(
                                'Login',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Visibility(
                        visible: true,
                        child: FutureBuilder<LoginResponse>(
                            future: makeRequest(url, usernameControler.text,
                                passwordControler.text),
                            builder: (context1, snapshot) {
                              if (snapshot.hasData) {
                                if (snapshot.data!.status!) {
                                  Future.delayed(Duration.zero, () async {
                                    sharedPreferences =
                                        await SharedPreferences.getInstance();
                                    sharedPreferences.setString(
                                        "Authentication_token",
                                        snapshot.data!.token!);
                                    sharedPreferences.setBool("is_Login", true);

                                    Navigator.of(context)
                                        .pushReplacement(MaterialPageRoute(
                                      builder: (context) => const HomePage(),
                                    ));
                                  });
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content: Text("Invalid details")));
                                }
                              }
                              return const Text("");
                            }),
                      ),
                      Container(
                        height: 200,
                        padding: const EdgeInsets.only(left: 100),
                        child: Image.asset(
                          height: 200,
                          width: 300,
                          'assets/images/pg.png',
                          fit: BoxFit.fill,
                        ),
                      ),
                    ]),
              ),
              Visibility(
                visible: _isVisible,
                child: Positioned(
                 top: MediaQuery.of(context).size.height*0.5 -50,
                  left: MediaQuery.of(context).size.width*0.5 -50,
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      color: Colors.orangeAccent,
                      borderRadius: BorderRadius.all(Radius.circular(6)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: Colors.blue,
                          backgroundColor: Colors.white,
                          semanticsLabel: "Loading....",
                          semanticsValue: "2",
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
