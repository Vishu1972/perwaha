import 'dart:developer';
import 'dart:io';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:perwha/model/ChargeAreaDetails.dart';
import 'package:perwha/model/JobDetails.dart';
import 'package:perwha/model/PhotographDetail.dart';
import 'package:perwha/pages/camerapage.dart';
import 'package:perwha/pages/homepage.dart';
import 'package:perwha/repo/repo.dart';

class Permit extends StatefulWidget {
  const Permit({super.key});

  @override
  State<Permit> createState() => _PermitState();
}

class _PermitState extends State<Permit> {
  String jobDefaultValue = 'Select Job Desc.';
  String chargeAreaDefaultValue = 'Select Charge Area.';
  var chargeAreaItems = ['Select Charge Area.'];
  var jobDescItems = ['Select Job Desc.'];
  late Future<JobDetails> jobDescFuture;


  @override
  void initState() {
    jobDescFuture = getPermit();
    setImageSection();
    super.initState();
  }
  final ImagePicker _picker = ImagePicker();
  List imageList = [];

  void setImageSection() {
    for(int i=0; i<8; i++) {
      imageList.add("");
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    /*24 is for notification bar on Android*/
    final double itemHeight = (size.height - kToolbarHeight - 24) / 2;
    final double itemWidth = size.width / 2;
    return SafeArea(
      child: Scaffold(
          body: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xffFFF7E1), Color(0xffFFFFEF)],
                end: Alignment.topCenter,
                begin: Alignment.bottomCenter)),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              Card(
                elevation: 8,
                child: Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                    ),
                    width: 359,
                    height: 48,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text('State',
                                style: TextStyle(
                                    fontWeight: FontWeight.w500, fontSize: 14)),
                            Text('GA',
                                style: TextStyle(
                                    fontWeight: FontWeight.w500, fontSize: 14)),
                            Text('PA',
                                style: TextStyle(
                                    fontWeight: FontWeight.w500, fontSize: 14)),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * .5 + 90,
                          height: 1,
                          color: Colors.black,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text('Maharastra'),
                            Text('Pune'),
                            Text('Aundh'),
                          ],
                        ),
                      ],
                    )),
              ),
              SizedBox(
                height: 13,
              ),
              Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(4))),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: FutureBuilder<JobDetails>(
                      future: jobDescFuture,
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          for(var jobItem in snapshot.data!.data!){
                            jobDescItems.add(jobItem.description!);
                          }
                          return DropdownButton<String>(
                            // Initial Value
                            value: jobDefaultValue,

                            // Down Arrow Icon
                            icon: const Icon(Icons.keyboard_arrow_down),

                            // Array list of items
                            items: jobDescItems.map((String items) {
                              return DropdownMenuItem(
                                value: items,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    items,
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              );
                            }).toList(),
                            // After selecting the desired option,it will
                            // change button value to selected value
                            onChanged: (String? newValue) {
                              setState(() {
                                jobDefaultValue = newValue!;
                              });
                            },
                          );
                        } else {
                          return DropdownButton<String>(
                            // Initial Value
                            value: jobDefaultValue,

                            // Down Arrow Icon
                            icon: const Icon(Icons.keyboard_arrow_down),

                            // Array list of items
                            items: jobDescItems.map((String items) {
                              return DropdownMenuItem(
                                value: items,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    items,
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              );
                            }).toList(),
                            // After selecting the desired option,it will
                            // change button value to selected value
                            onChanged: (String? newValue) {
                              setState(() {
                                jobDefaultValue = newValue!;
                              });
                            },
                          );
                        }
                      }),
                ),
              ),
              SizedBox(
                height: 11,
              ),
              Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(4))),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: FutureBuilder<ChargeAreaDetails>(
                      future: getChargeArea(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          for(var chargeItem in snapshot.data!.data!){
                            chargeAreaItems.add(chargeItem.description!);
                          }
                          return DropdownButton<String>(
                            // Initial Value
                            value: chargeAreaDefaultValue,

                            // Down Arrow Icon
                            icon: const Icon(Icons.keyboard_arrow_down),

                            // Array list of items
                            items: chargeAreaItems.map((String items) {
                              return DropdownMenuItem(
                                value: items,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(items,
                                      style: TextStyle(fontSize: 14)),
                                ),
                              );
                            }).toList(),
                            // After selecting the desired option,it will
                            // change button value to selected value
                            onChanged: (String? newValue) {
                              setState(() {
                                chargeAreaDefaultValue = newValue!;
                              });
                            },
                          );
                        }
                        {
                          return DropdownButton<String>(
                            // Initial Value
                            value: chargeAreaDefaultValue,
                            // Down Arrow Icon
                            icon: const Icon(Icons.keyboard_arrow_down),

                            // Array list of items
                            items: chargeAreaItems.map((String items) {
                              return DropdownMenuItem(
                                value: items,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(items,
                                      style: TextStyle(fontSize: 14)),
                                ),
                              );
                            }).toList(),
                            // After selecting the desired option,it will
                            // change button value to selected value
                            onChanged: (String? newValue) {
                              setState(() {
                                chargeAreaDefaultValue = newValue!;
                              });
                            },
                          );
                        }
                      }),
                ),
              ),
              SizedBox(
                height: 12,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width,
                child: TextField(
                  decoration: InputDecoration(
                    filled: true,
                    focusColor: Colors.white,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(),
                    hintText: 'Enter Locality',
                    labelText: 'Locality',
                  ),
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(
                height: 13,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width,
                child: TextField(
                  decoration: InputDecoration(
                    filled: true,
                    focusColor: Colors.white,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(),
                    hintText: 'Enter Building Name',
                    labelText: 'Building / Society Name',
                  ),
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(
                height: 13,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width,
                child: TextField(
                  maxLines: 5,
                  decoration: InputDecoration(
                    filled: true,
                    focusColor: Colors.white,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(),
                    hintText: 'Remarks',
                    labelText: 'Remarks',
                  ),
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(
                height: 17,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Photos',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      )),
                  Text('7/8',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
                ],
              ),
              SizedBox(
                height: 1,
              ),
              Divider(
                height: 10,
                thickness: 1.5,
                indent: 0,
                endIndent: 0,
                color: Colors.black,
              ),
              InkWell(
                // onTap: () async {
                //   await availableCameras().then(
                //     (value) => Navigator.push(
                //       context,
                //       MaterialPageRoute(
                //         builder: (context) => CameraPage(
                //           cameras: value,
                //         ),
                //       ),
                //     ),
                //   );
                // },
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.4,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.black, width: 1)),
                  child: FutureBuilder<PhotographDetail>(
                      future: getPhotoGraphDetails(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {

                          return GridView.count(
                            childAspectRatio: (1.65 / 3),
                            shrinkWrap: false,
                            crossAxisCount: 4,
                            children:
                                List.generate(snapshot.data!.data!.length, (i) {
                              return GestureDetector(
                                onTap: (()=>{
                                  takephoto(i, ImageSource.camera)
                               }),
                                child: Container(
                                  margin: EdgeInsets.all(8),
                                  width: 80,
                                  height: 162,
                                  child: DottedBorder(
                                    padding: EdgeInsets.all(1),
                                    child: imageList[i] == ""
                                      ?Container(
                                      padding: EdgeInsets.symmetric(horizontal: 4),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [

                                           Icon(Icons.add, size: 32),
                                            Text(
                                                snapshot
                                                    .data!.data![i].description!,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(fontSize: 13))
                                          ]),
                                      )
                                     :ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                       child: Container(
                                          width: 80,
                                          height: 162,
                                          child: Image.file(File(imageList[i]), fit: BoxFit.fill,)
                                    ),
                                     ),
                                    borderType: BorderType.RRect,
                                    radius: Radius.circular(8),
                                    dashPattern: [5, 5],
                                    color: Colors.grey,
                                    strokeWidth: 2,
                                  ),
                                ),
                              );
                            }),
                          );
                        } else {
                          return Container(
                            child: Center(
                              child: Text(
                                "Please wait...",
                                style: TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.w400),
                              ),
                            ),
                          );
                        }
                      }),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Color(0xffF5A443)),
                    onPressed: () => {},
                    child: Text(
                      'Submit',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  ElevatedButton(
                      style:
                          ElevatedButton.styleFrom(primary: Color(0xffF5A443)),
                      onPressed: () {
                        Navigator.of(context).pop(MaterialPageRoute(
                            builder: (context) => const HomePage()));
                      },
                      child: Text(
                        'Cancel',
                        style: TextStyle(color: Colors.white),
                      )),
                ],
              )
            ],
          ),
        ),
      )),
    );
  }

  void  takephoto(int index, ImageSource source)async{
    final xFile = await _picker.pickImage(source: source);
    setState(() {
      imageList[index] = xFile!.path;
    });
  }

  @override
  void didUpdateWidget(Permit oldWidget){
    super.didUpdateWidget(oldWidget);
  }
}
