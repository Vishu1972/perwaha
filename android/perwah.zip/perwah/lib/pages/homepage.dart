import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:perwha/model/PermitResponse.dart';
import 'package:perwha/pages/loginpage.dart';
import 'package:perwha/pages/permit.dart';
import 'package:perwha/repo/repo.dart';
import 'package:perwha/utils/util.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/ProfileDetails.dart';
import 'permitdetailspage.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int total = 0;
  int approved = 0;
  int rejected = 0;
  int pending = 0;
  int live = 0;
  int clousre = 0;
  int closed = 0;
  int suspended = 0;

  late SharedPreferences sharedPreferences;
  late bool _isVisible = true;

  

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          actions: [
            const Icon(Icons.search_rounded, size: 30),
            const Icon(
              Icons.filter_alt_outlined,
              size: 30,
            ),
            Image.asset(
              'assets/images/ce.png',
              width: 70,
              fit: BoxFit.fitWidth,
            )
          ],
          titleSpacing: 0.0,
          title: const Text(
            'PerWAH',
            style: TextStyle(color: Colors.black),
          ),
          iconTheme: const IconThemeData(color: Colors.black),
          backgroundColor: Colors.white,
        ),
        body: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [Color(0xffFFF7E1), Color(0xffFFFFEF)],
                  end: Alignment.topCenter,
                  begin: Alignment.bottomCenter)),
          child: Column(
            children: [
              const SizedBox(
                height: 8,
              ),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Container(
                  height: 38,
                  width: 80,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.all(1),
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      border:
                      Border.all(width: 2, color: const Color(0xff0066FE))),
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: Color(0xff0066FE)),
                        children: [
                          TextSpan(
                              text: '$total\n',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                          TextSpan(text: 'Total')
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
                Container(
                  height: 38,
                  width: 80,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.all(1),
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      border:
                      Border.all(width: 2, color: const Color(0xff1B6700))),
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: Color(0xff1B6700)),
                        children: [
                          TextSpan(
                              text: '$approved\n',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                          TextSpan(text: 'Approved')
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
                Container(
                  height: 38,
                  width: 80,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.all(1),
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      border:
                      Border.all(width: 2, color: const Color(0xffFFB800))),
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: Color(0xffFFB800)),
                        children: [
                          TextSpan(
                              text: '$pending\n',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                          TextSpan(text: 'Pending')
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
                Container(
                  height: 38,
                  width: 80,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.all(1),
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      border:
                      Border.all(width: 2, color: const Color(0xffFF0000))),
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: Color(0xffFF0000)),
                        children: [
                          TextSpan(
                              text: '$rejected\n',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                          TextSpan(text: 'Rejected')
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              const SizedBox(
                height: 12,
              ),
              Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    width: 348,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                      border:
                      Border.all(width: 2, color: const Color(0xff2DAE00)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'From Approved',
                          style: TextStyle(color: Color(0xff2DAE00)),
                        ),
                        const SizedBox(
                          height: 7,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              height: 38,
                              width: 80,
                              alignment: Alignment.center,
                              margin: const EdgeInsets.all(1),
                              padding: const EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(4)),
                                  border: Border.all(
                                      width: 2,
                                      color: const Color(0xffDA9D00))),
                              child: RichText(
                                text: TextSpan(
                                    style: TextStyle(color: Color(0xffDA9D00)),
                                    children: [
                                      TextSpan(
                                          text: '$live\n',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14)),
                                      TextSpan(text: 'Live')
                                    ]),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Container(
                              height: 38,
                              width: 80,
                              alignment: Alignment.center,
                              margin: const EdgeInsets.all(1),
                              padding: const EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(4)),
                                  border: Border.all(
                                      width: 2,
                                      color: const Color(0xff2DAE00))),
                              child: RichText(
                                text: TextSpan(
                                    style: TextStyle(color: Color(0xff2DAE00)),
                                    children: [
                                      TextSpan(
                                          text: '$clousre\n',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14)),
                                      TextSpan(
                                          text: 'Closure Applied',
                                          style: TextStyle(fontSize: 10))
                                    ]),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Container(
                              height: 38,
                              width: 80,
                              alignment: Alignment.bottomCenter,
                              margin: const EdgeInsets.all(1),
                              padding: const EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(4)),
                                  border: Border.all(
                                      width: 2,
                                      color: const Color(0xff1B6700))),
                              child: RichText(
                                text: TextSpan(
                                    style: TextStyle(color: Color(0xff1B6700)),
                                    children: [
                                      TextSpan(
                                          text: '$closed\n',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14)),
                                      TextSpan(text: 'Closed')
                                    ]),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Container(
                              height: 38,
                              width: 80,
                              alignment: Alignment.center,
                              margin: const EdgeInsets.all(1),
                              padding: const EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(4)),
                                  border: Border.all(
                                      width: 2,
                                      color: const Color(0xffD30000))),
                              child: RichText(
                                text: TextSpan(
                                    style: TextStyle(color: Color(0xffD30000)),
                                    children: [
                                      TextSpan(
                                          text: '$suspended\n',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14)),
                                      TextSpan(text: 'Suspended')
                                    ]),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
              Card(
                elevation: 8,
                child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1),
                      borderRadius: const BorderRadius.all(Radius.circular(4)),
                    ),
                    width: 359,
                    height: 48,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: const [
                            Text(
                              'State',
                              textAlign: TextAlign.start,
                              style: TextStyle(fontWeight: FontWeight.w500),
                            ),
                            Text('GA', style: TextStyle(fontWeight: FontWeight.w500), textAlign: TextAlign.end),
                            Text('PA',  style: TextStyle(fontWeight: FontWeight.w500),textAlign: TextAlign.end),
                          ],
                        ),
                        Container(
                          width: MediaQuery
                              .of(context)
                              .size
                              .width * .5 + 90,
                          height: 1,
                          color: Colors.black,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: const [
                            Text(
                              'Maharastra',
                              textAlign: TextAlign.start,
                            ),
                            Text('Pune', textAlign: TextAlign.start),
                            Text('Aundh', textAlign: TextAlign.end),
                          ],
                        ),
                      ],
                    )),
              ),
              SizedBox(
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                height: MediaQuery
                    .of(context)
                    .size
                    .height * 0.656,
                child: Padding(
                    padding:  EdgeInsets.all(5),
                    child: FutureBuilder<PermitResponse>(
                      future: getPermitDetails(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          total = snapshot.data!.total!;
                          approved = snapshot.data!.approved!;
                          pending = snapshot.data!.pending!;
                          rejected = snapshot.data!.rejected!;
                          live = snapshot.data!.live!;
                          clousre = snapshot.data!.closureApplied!;
                          closed = snapshot.data!.closed!;
                          suspended = snapshot.data!.suspended!;
                        }

                        if (snapshot.hasData) {
                          return ListView.builder(
                            itemCount: snapshot.data!.permitDetails!.length,
                            scrollDirection: Axis.vertical,
                            itemBuilder: (BuildContext context, int index) {
                              return GestureDetector(
                                onTap: (() {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) =>
                                          PermitDetailsPage(snapshot.data!.permitDetails![index].id!.toString())));
                                }),
                                child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(
                                            width: 1,
                                            color: (snapshot.data!
                                                .permitDetails![index].status!
                                                == "Pending") ? Color(
                                                0xffDA9D00) : (snapshot.data!
                                                .permitDetails![index].status!
                                                 == "Live")
                                                ? Color(0xff268903)
                                                : (snapshot.data!
                                                .permitDetails![index].status!
                                                == "Rejected") ? const Color(
                                                0xffFF0000)
                                                : (snapshot.data!
                                            .permitDetails![index].status
                                            == "Closed")
                                                ? Color(0xff1B6700)
                                                :(snapshot.data!.permitDetails![index].status!
                                            == "Suspended")
                                                ? Color(0xffD30000)
                                                : Color(0xffDA9D00)


                                        )),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment : CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                          EdgeInsets.fromLTRB(8, 5, 0, 0),
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                snapshot
                                                    .data!
                                                    .permitDetails![index]
                                                    .jobDecs!,
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(snapshot
                                                  .data!
                                                  .permitDetails![index]
                                                  .locality!),
                                              Text(snapshot
                                                  .data!
                                                  .permitDetails![index]
                                                  .building!),
                                              Text(dateFormater(snapshot
                                                  .data!
                                                  .permitDetails![index]
                                                  .createTime!),),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(right: 5,top: 5),
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Container(
                                                    width: 12,
                                                    height: 12,
                                                    decoration: BoxDecoration(
                                                        color: (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Pending") ? Color(
                                                            0xffDA9D00) : (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Live")
                                                            ? Color(0xff268903)
                                                            : (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Rejected") ? const Color(
                                                            0xffFF0000)
                                                            : (snapshot.data!
                                                            .permitDetails![index].status
                                                            == "Closed")
                                                            ? Color(0xff1B6700)
                                                            :(snapshot.data!.permitDetails![index].status!
                                                            == "Suspended")
                                                            ? Color(0xffD30000)
                                                            : Color(0xffDA9D00),
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                6))),
                                                  ),
                                                  SizedBox(
                                                    width: 4,
                                                  ),
                                                  Text(
                                                    snapshot
                                                        .data!
                                                        .permitDetails![index]
                                                        .status!,
                                                    style: TextStyle(
                                                        color: (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Pending") ? Color(
                                                            0xffDA9D00) : (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Live")
                                                            ? Color(0xff268903)
                                                            : (snapshot.data!
                                                            .permitDetails![index].status!
                                                            == "Rejected") ? const Color(
                                                            0xffFF0000)
                                                            : (snapshot.data!
                                                            .permitDetails![index].status
                                                            == "Closed")
                                                            ? Color(0xff1B6700)
                                                            :(snapshot.data!.permitDetails![index].status!
                                                            == "Suspended")
                                                            ? Color(0xffD30000)
                                                            : Color(0xffDA9D00),
                                                        fontWeight:
                                                        FontWeight.w600),
                                                  ),
                                                  SizedBox(height: 10,)
                                                ],
                                              ),
                                              Text(
                                                  dateFormater(snapshot
                                                      .data!
                                                      .permitDetails![index]
                                                      .statusTime!),
                                                   style: TextStyle(color: (snapshot.data!
                                                  .permitDetails![index].status!
                                              == "Pending") ? Color(
                                                  0xffDA9D00) : (snapshot.data!
                                                  .permitDetails![index].status!
                                                  == "Live")
                                                  ? Color(0xff268903)
                                                  : (snapshot.data!
                                                  .permitDetails![index].status!
                                                  == "Rejected") ? const Color(
                                                  0xffFF0000)
                                                  : (snapshot.data!
                                                  .permitDetails![index].status
                                                  == "Closed")
                                                  ? Color(0xff1B6700)
                                                  :(snapshot.data!.permitDetails![index].status!
                                                  == "Suspended")
                                                  ? Color(0xffD30000)
                                                  : Color(0xffDA9D00)))
                                            ],
                                          ),
                                        ),
                                      ],
                                    )),
                              );
                            },

                          );
                        } else {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Visibility(
                              visible: _isVisible = true,
                              child: Center(
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: Colors.orangeAccent),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircularProgressIndicator(
                                        color: Colors.white,
                                        semanticsValue: "2",
                                        semanticsLabel: "Loading...",
                                        backgroundColor: Colors.blueGrey,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        }
                      },
                    )),
              )
            ],
          ),
        ),
        floatingActionButton: SizedBox(
          height: 50,
          width: 150,
          child: FloatingActionButton.extended(
            onPressed: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const Permit()));
            },
            backgroundColor: const Color(0xffF5A443),
            icon: const Icon(
              Icons.add_box_outlined,
              size: 28,
              color: Colors.white,
            ),
            label: const Text(
              "New Permit",
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 16, height: 1, color: Colors.white),
            ),
            shape:
            BeveledRectangleBorder(borderRadius: BorderRadius.circular(2)),
            tooltip: "New Permit",
          ),
        ),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: FutureBuilder<ProfileDetails>(
            future: getProfileDetails(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                _saveProfileDetails(
                    snapshot.data!.data!.name!,
                    snapshot.data!.data!.designation!,
                    snapshot.data!.data!.mobile!,
                    snapshot.data!.data!.email!,
                    snapshot.data!.data!.state!,
                    snapshot.data!.data!.geoArea!,
                    snapshot.data!.data!.projectArea![0].description!);
                return Column(
                  children: [
                    Stack(
                      children: [
                        Positioned(
                            child: Image.asset(
                              'assets/images/rec.png',
                            )),
                        Positioned(
                          //  top: 30,
                          // left: MediaQuery.of(context).size.width * 0.4 - 125,
                          child: Image.asset(
                            'assets/images/ce.png',
                          ),
                        ),
                        Positioned(
                          top: 24,
                          left: 24,
                          child: GestureDetector(
                            onTap: () {
                              Navigator.of(context).pop(
                                MaterialPageRoute(
                                  builder: (context) => const HomePage(),
                                ),
                              );
                            },
                            child: const Icon(
                              Icons.arrow_back,
                              color: Colors.black,
                              size: 24.0,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          left: 0,
                          child: Container(
                            padding: EdgeInsets.all(11),
                            width: 300,
                            alignment: Alignment.center,
                            child: Text(
                              textAlign: TextAlign.center,
                              snapshot.data!.data!.name!,
                              style: TextStyle(
                                  fontWeight: FontWeight.w400, fontSize: 24),
                            ),
                          ),
                        )
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: const BoxDecoration(
                          color: Color(0x32CB8C52),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      width: 250,
                      child: Text(

                        snapshot.data!.data!.designation!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Color(0xffCC6F00),
                            fontWeight: FontWeight.w400),
                        textScaleFactor: 1.5,
                      ),
                    ),
                    const SizedBox(
                      height: 11,
                    ),
                    Container(
                      decoration: const BoxDecoration(color: Color(0x36D9D9D9)),
                      padding: const EdgeInsets.all(14),
                      height: 80,
                      width: 244,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: const [
                              Icon(Icons.call),
                              Icon(Icons.mail_outline),
                            ],
                          ),
                          const SizedBox(
                            width: 32,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('+91 ${snapshot.data!.data!.mobile!}'
                                ,
                                style: TextStyle(),
                              ),
                              Text(
                                snapshot.data!.data!.email!,
                                style: TextStyle(),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 31,
                    ),
                    Container(
                      decoration: const BoxDecoration(color: Color(0x36D9D9D9)),
                      padding: const EdgeInsets.all(14),
                      height: 80,
                      width: 244,
                      child: Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text('State'),
                              Text('GA'),
                              Text('PA'),
                            ],
                          ),
                          const SizedBox(width: 20),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(snapshot.data!.data!.state!,),
                              Text(snapshot.data!.data!.geoArea!,),
                              Text(snapshot.data!.data!.projectArea![0]
                                  .description!,),
                            ],
                          )
                        ],
                      ),
                    ),
                    Stack(
                      children: [
                        Positioned(
                          // right: 0,
                          // bottom: 0,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Image.asset(
                              height: 200,
                              'assets/images/pg.png',
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 150,
                          left: 20,
                          child: SizedBox(
                            width: 102,
                            height: 36,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: const Color(0xFFF5A443),
                                ),
                                onPressed: () {
                                  _logout();
                                  Navigator.of(context).pushReplacement(
                                      MaterialPageRoute(
                                          builder: (context) =>
                                          const LoginPage()));
                                },
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: const [
                                    Icon(
                                      Icons.logout,
                                      color: Colors.white,
                                    ),
                                    Text(
                                      "Logout",
                                      style: TextStyle(color: Colors.white),
                                    )
                                  ],
                                )),
                          ),
                        )
                      ],
                    )
                  ],
                );
              } else {
                return Visibility(
                  visible: _isVisible = true,
                  child: Center(
                    child: Container(
                      width: 100,
                      height: 100,

                      decoration: BoxDecoration(
                          color: Colors.blueGrey,
                          borderRadius: BorderRadius.all(Radius.circular(6))

                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: Colors.blue,
                            backgroundColor: Colors.white,
                            semanticsLabel: "Loading....",
                            semanticsValue: "2",
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
            },
          ),
        ),
      ),
    );
  }



  _logout() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      sharedPreferences.setBool("is_Login", false);
    });
  }


  _saveProfileDetails(String userName, String degination, String mobile,
      String email, String state, String geoArea, String description,) async {
    sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString("user_name", userName);
    sharedPreferences.setString("degination", degination);
    sharedPreferences.setString("mobile", mobile);
    sharedPreferences.setString("email", email);
    sharedPreferences.setString("state", state);
    sharedPreferences.setString("GA", geoArea);
    sharedPreferences.setString("PA", description);
  }
}
