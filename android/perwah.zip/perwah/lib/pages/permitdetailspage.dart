import 'dart:convert';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:perwha/model/PermitDocuments.dart';
import 'package:perwha/utils/util.dart';

import '../repo/repo.dart';
import 'homepage.dart';

class PermitDetailsPage extends StatefulWidget {
  PermitDetailsPage(this.id, {super.key});

  String id;

  @override
  State<PermitDetailsPage> createState() => _PermitDetailsPageState();
}

class _PermitDetailsPageState extends State<PermitDetailsPage> {
  PageController controller = PageController();
  List<Widget> fruits = <Widget>[];
  double fill = 10;
  final List<bool> _selectedFruits = <bool>[true, false];
  late final ScrollBehavior? scrollBehavior;

  @override
  Widget build(BuildContext context) {
    List<Widget> pager = <Widget>[];

    return SafeArea(
      child: Scaffold(
        body: Container(
          alignment: Alignment.topCenter,
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [Color(0xffFFF7E1), Color(0xffFFFFEF)],
                  end: Alignment.topCenter,
                  begin: Alignment.bottomCenter)),
          child: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop(
                        MaterialPageRoute(
                          builder: (context) => const HomePage(),
                        ),
                      );
                    },
                    child: Container(
                      alignment: Alignment.topLeft,
                      padding: const EdgeInsets.fromLTRB(20, 20, 0, 0),
                      width: MediaQuery.of(context).size.width,
                      child: const Icon(
                        Icons.arrow_back,
                        color: Colors.black,
                        size: 30.0,
                      ),
                    ),
                  ),
                  Card(
                    elevation: 8,
                    child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black, width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(4)),
                        ),
                        width: 359,
                        height: 48,
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: const [
                                Text(
                                  'State',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  'GA',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  'PA',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                            Container(
                              width:
                                  MediaQuery.of(context).size.width * .5 + 90,
                              height: 1,
                              color: Colors.black,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: const [
                                Text('Maharastra', textAlign: TextAlign.center),
                                Text('Pune', textAlign: TextAlign.center),
                                Text('Aundh', textAlign: TextAlign.center),
                              ],
                            ),
                          ],
                        )),
                  ),
                  FutureBuilder<PermitDocuments>(
                      future: getdocumentbypermitid(widget.id),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          for(var permidImg in snapshot.data!.permitImgData!){
                            pager.add( SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 320,
                              child: Image.network(permidImg.image!),
                            ),);
                          }
                          fruits.add(Text("Approved(${snapshot.data!.permitImgData!.length})"));
                          fruits.add(Text("Closure(${snapshot.data!.closureImgData!.length})"));
                          return Column(children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 320,
                              child: PageView(
                                children: pager,
                                onPageChanged: (index) => {
                                  setState(() => {fill = (index + 1) * 10})
                                },
                                scrollDirection: Axis.horizontal,
                                controller: controller,
                              ),
                            ),
                            Stack(
                              // alignment: Alignment.center,
                              children: [
                                Container(
                                  height: 10,
                                  width: pager.length * 10,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1, color: Colors.black),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(5))),
                                ),
                                Container(
                                  height: 10,
                                  width: fill,
                                  decoration: const BoxDecoration(
                                      color: Colors.black,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(5))),
                                )
                              ],
                            ),
                            ToggleButtons(
                              direction: Axis.horizontal,
                              onPressed: (int index) {
                                setState(() {
                                  // The button that is tapped is set to true, and the others to false.
                                  for (int i = 0;
                                      i < _selectedFruits.length;
                                      i++) {
                                    _selectedFruits[i] = i == index;
                                  }
                                });
                              },
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(20)),
                              selectedBorderColor: const Color(0xffF5A443),
                              selectedColor: const Color(0xffF5A443),
                              fillColor:
                                  const Color.fromARGB(255, 218, 226, 231),
                              color: const Color(0xff263238),
                              constraints: const BoxConstraints(
                                minHeight: 40.0,
                                minWidth: 150.0,
                              ),
                              isSelected: _selectedFruits,
                              children: fruits,
                            ),
                            const SizedBox(
                              height: 52,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(23, 0, 0, 0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children:  [
                                      Text(
                                        'Submitted on',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(dateFormater(snapshot.data!.submittedDate!))
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 0, 30, 0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children:  [
                                      Text(
                                        'Action on',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(dateFormater(snapshot.data!.actionDate!))
                                    ],
                                  ),
                                )
                              ],
                            ),
                            const SizedBox(
                              height: 14,
                            ),
                            Container(
                              height: 104,
                              width: 338,
                              decoration: BoxDecoration(
                                color: const Color(0x40D9D9D9),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(8, 5, 0, 0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children:  [
                                        Text(
                                          snapshot.data!.jobDescription!,
                                          style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          snapshot.data!.building!,
                                          style: TextStyle(fontSize: 14),
                                        ),
                                        Text(
                                          snapshot.data!.locality!,
                                          style: TextStyle(fontSize: 14),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            width: 12,
                                            height: 12,
                                            decoration: const BoxDecoration(
                                                color: Color(0xff268903),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(6))),
                                          ),
                                          const SizedBox(
                                            width: 4,
                                          ),
                                          const Padding(
                                            padding: EdgeInsets.all(8.0),
                                            child: Text(
                                              'Approved',
                                              style: TextStyle(
                                                  color: Color(0xff268903),
                                                  fontWeight: FontWeight.w600),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 32,
                            ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(23, 0, 0, 0),
                              child: Row(
                                children: const [
                                  Text(
                                    'Remarks Trail',
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 19,
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: MediaQuery.of(context).size.height * 0.5,
                              child: ListView.builder(
                                itemCount:snapshot.data!.permitRemark!.length,
                                physics: BouncingScrollPhysics(),
                                  scrollDirection: Axis.vertical,
                                  itemBuilder:(context, index) {
                                    return Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              16, 0, 0, 0),
                                          child: SizedBox(
                                            width: 25,
                                            child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Column(
                                                  children: [
                                                    Container(
                                                      width: 1,
                                                      height: 30,
                                                      color: Colors.blue,
                                                    ),
                                                    Container(
                                                      width: 1,
                                                      height: 90,
                                                      color: Colors.black,
                                                    ),
                                                  ],
                                                ),
                                                Positioned(
                                                  top: 12,
                                                  child: Container(
                                                    width: 16,
                                                    height: 16,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          10),
                                                      color: const Color(
                                                          0xffD9D9D9),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Column(
                                              children: [
                                                Row(
                                                  children: [
                                                     Text(
                                                      snapshot.data!.permitRemark![index].senderBy!,
                                                      style: TextStyle(
                                                          fontWeight:
                                                          FontWeight.w500),
                                                    ),
                                                    const SizedBox(
                                                      width: 80,
                                                    ),
                                                    Container(
                                                        child:  Text(
                                                          dateFormater(snapshot.data!.permitRemark![index].date!),
                                                          style: TextStyle(
                                                              fontWeight:
                                                              FontWeight.w500),
                                                        )),
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                Container(
                                                  width: 300,
                                                  decoration: BoxDecoration(
                                                      color: const Color(
                                                          0x40D9D9D9),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          8)),
                                                  child:  Padding(
                                                    padding:
                                                    EdgeInsets.fromLTRB(
                                                        10, 7, 10, 12),
                                                    child: Text(
                                                        snapshot.data!.permitRemark![index].remark!,
                                                        style: TextStyle(
                                                            fontSize: 14)),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    );
                                    // Container(
                                    //     child: Row(
                                    //   children: [
                                    //     Padding(
                                    //       padding: const EdgeInsets.fromLTRB(
                                    //           16, 0, 0, 0),
                                    //       child: Container(
                                    //         width: 25,
                                    //         child: Stack(
                                    //           alignment: Alignment.center,
                                    //           children: [
                                    //             Column(
                                    //               children: [
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 30,
                                    //                   color: Colors.blue,
                                    //                 ),
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 90,
                                    //                   color: Colors.black,
                                    //                 ),
                                    //               ],
                                    //             ),
                                    //             Positioned(
                                    //               top: 12,
                                    //               child: Container(
                                    //                 width: 16,
                                    //                 height: 16,
                                    //                 decoration: BoxDecoration(
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           10),
                                    //                   color: const Color(
                                    //                       0xffD9D9D9),
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ),
                                    //       ),
                                    //     ),
                                    //     Row(
                                    //       children: [
                                    //         Column(children: [
                                    //           Row(
                                    //             children: [
                                    //               Container(
                                    //                   child: const Text(
                                    //                 'AIC Contact Name',
                                    //                 style: TextStyle(
                                    //                     fontWeight:
                                    //                         FontWeight.w500),
                                    //               )),
                                    //               const SizedBox(
                                    //                 width: 80,
                                    //               ),
                                    //               Container(
                                    //                   child: const Text(
                                    //                 '29 Sep-11:30AM ',
                                    //                 style: TextStyle(
                                    //                     fontWeight:
                                    //                         FontWeight.w500),
                                    //               )),
                                    //             ],
                                    //           ),
                                    //           const SizedBox(
                                    //             height: 5,
                                    //           ),
                                    //           Container(
                                    //             width: 300,
                                    //             decoration: BoxDecoration(
                                    //                 color:
                                    //                     const Color(0x40D9D9D9),
                                    //                 borderRadius:
                                    //                     BorderRadius.circular(
                                    //                         8)),
                                    //             child: const Padding(
                                    //               padding: EdgeInsets.fromLTRB(
                                    //                   10, 7, 10, 12),
                                    //               child: Text(
                                    //                   'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
                                    //                   style: TextStyle(
                                    //                       fontSize: 14)),
                                    //             ),
                                    //           ),
                                    //         ]),
                                    //       ],
                                    //     ),
                                    //   ],
                                    // )),
                                    // const SizedBox(
                                    //   height: 11,
                                    // ),
                                    // Padding(
                                    //   padding: const EdgeInsets.fromLTRB(
                                    //       23, 0, 0, 0),
                                    //   child: Row(
                                    //     children: [
                                    //       const Text(
                                    //         'Closure Details',
                                    //         textAlign: TextAlign.start,
                                    //         style: TextStyle(
                                    //             fontSize: 15,
                                    //             fontWeight: FontWeight.w500),
                                    //       ),
                                    //     ],
                                    //   ),
                                    // ),
                                    // const SizedBox(
                                    //   height: 11,
                                    // ),
                                    // const SizedBox(
                                    //   height: 12,
                                    // ),
                                    // Container(
                                    //     child: Row(
                                    //   children: [
                                    //     Padding(
                                    //       padding: const EdgeInsets.fromLTRB(
                                    //           16, 0, 0, 0),
                                    //       child: Container(
                                    //         width: 25,
                                    //         child: Stack(
                                    //           alignment: Alignment.center,
                                    //           children: [
                                    //             Column(
                                    //               children: [
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 30,
                                    //                   color: Colors.blue,
                                    //                 ),
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 90,
                                    //                   color: Colors.black,
                                    //                 ),
                                    //               ],
                                    //             ),
                                    //             Positioned(
                                    //               top: 12,
                                    //               child: Container(
                                    //                 width: 16,
                                    //                 height: 16,
                                    //                 decoration: BoxDecoration(
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           10),
                                    //                   color: const Color(
                                    //                       0xffD9D9D9),
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ),
                                    //       ),
                                    //     ),
                                    //     Row(
                                    //       children: [
                                    //         Column(
                                    //           children: [
                                    //             Row(
                                    //               children: [
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   'TPE Contact Name',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //                 const SizedBox(
                                    //                   width: 80,
                                    //                 ),
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   '29 Sep-10:30AM ',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //               ],
                                    //             ),
                                    //             const SizedBox(
                                    //               height: 5,
                                    //             ),
                                    //             Container(
                                    //               width: 300,
                                    //               decoration: BoxDecoration(
                                    //                   color: const Color(
                                    //                       0x40D9D9D9),
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           8)),
                                    //               child: const Padding(
                                    //                 padding:
                                    //                     EdgeInsets.fromLTRB(
                                    //                         10, 7, 10, 12),
                                    //                 child: Text(
                                    //                     'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
                                    //                     style: TextStyle(
                                    //                         fontSize: 15)),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ),
                                    //       ],
                                    //     ),
                                    //   ],
                                    // )),
                                    // Container(
                                    //   child: Row(
                                    //     children: [
                                    //       Padding(
                                    //         padding: const EdgeInsets.fromLTRB(
                                    //             16, 0, 0, 0),
                                    //         child: Container(
                                    //           width: 25,
                                    //           child: Stack(
                                    //             alignment: Alignment.center,
                                    //             children: [
                                    //               Column(
                                    //                 children: [
                                    //                   Container(
                                    //                     width: 1,
                                    //                     height: 30,
                                    //                     color: Colors.blue,
                                    //                   ),
                                    //                   Container(
                                    //                     width: 1,
                                    //                     height: 90,
                                    //                     color: Colors.black,
                                    //                   ),
                                    //                 ],
                                    //               ),
                                    //               Positioned(
                                    //                 top: 12,
                                    //                 child: Container(
                                    //                   width: 16,
                                    //                   height: 16,
                                    //                   decoration: BoxDecoration(
                                    //                     borderRadius:
                                    //                         BorderRadius
                                    //                             .circular(10),
                                    //                     color: const Color(
                                    //                         0xffD9D9D9),
                                    //                   ),
                                    //                 ),
                                    //               ),
                                    //             ],
                                    //           ),
                                    //         ),
                                    //       ),
                                    //       Row(children: [
                                    //         Column(
                                    //           children: [
                                    //             Row(
                                    //               children: [
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   'AIC Contact Name',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //                 const SizedBox(
                                    //                   width: 80,
                                    //                 ),
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   '29 Sep-11:35AM ',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //               ],
                                    //             ),
                                    //             const SizedBox(
                                    //               height: 5,
                                    //             ),
                                    //             Container(
                                    //               width: 300,
                                    //               decoration: BoxDecoration(
                                    //                   color: const Color(
                                    //                       0x40D9D9D9),
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           8)),
                                    //               child: const Padding(
                                    //                 padding:
                                    //                     EdgeInsets.fromLTRB(
                                    //                         10, 7, 10, 12),
                                    //                 child: Text(
                                    //                     'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
                                    //                     style: TextStyle(
                                    //                         fontSize: 15)),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         )
                                    //       ])
                                    //     ],
                                    //   ),
                                    // ),
                                    // Container(
                                    //     child: Row(
                                    //   crossAxisAlignment:
                                    //       CrossAxisAlignment.start,
                                    //   children: [
                                    //     Padding(
                                    //       padding: const EdgeInsets.fromLTRB(
                                    //           16, 0, 0, 0),
                                    //       child: Container(
                                    //         width: 25,
                                    //         child: Stack(
                                    //           alignment: Alignment.center,
                                    //           children: [
                                    //             Column(
                                    //               children: [
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 30,
                                    //                   color: Colors.blue,
                                    //                 ),
                                    //                 Container(
                                    //                   width: 1,
                                    //                   height: 90,
                                    //                   color: Colors.black,
                                    //                 ),
                                    //               ],
                                    //             ),
                                    //             Positioned(
                                    //               top: 12,
                                    //               child: Container(
                                    //                 width: 16,
                                    //                 height: 16,
                                    //                 decoration: BoxDecoration(
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           10),
                                    //                   color: const Color(
                                    //                       0xffD9D9D9),
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ),
                                    //       ),
                                    //     ),
                                    //     Row(
                                    //       children: [
                                    //         Column(
                                    //           children: [
                                    //             Row(
                                    //               children: [
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   'TPE Contact Name',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //                 const SizedBox(
                                    //                   width: 80,
                                    //                 ),
                                    //                 Container(
                                    //                     child: const Text(
                                    //                   '29 Sep-10:30AM ',
                                    //                   style: TextStyle(
                                    //                       fontWeight:
                                    //                           FontWeight.w500),
                                    //                 )),
                                    //               ],
                                    //             ),
                                    //             const SizedBox(
                                    //               height: 5,
                                    //             ),
                                    //             Container(
                                    //               width: 300,
                                    //               decoration: BoxDecoration(
                                    //                   color: const Color(
                                    //                       0x40D9D9D9),
                                    //                   borderRadius:
                                    //                       BorderRadius.circular(
                                    //                           8)),
                                    //               child: Column(
                                    //                 children: [
                                    //                   const TextField(
                                    //                     maxLines: 3,
                                    //                     decoration:
                                    //                         InputDecoration(
                                    //                       filled: true,
                                    //                       focusColor:
                                    //                           Colors.white,
                                    //                       fillColor:
                                    //                           Colors.white,
                                    //                       border:
                                    //                           OutlineInputBorder(),
                                    //                       hintText: '',
                                    //                       labelText: 'Remarks',
                                    //                     ),
                                    //                     style: TextStyle(
                                    //                         fontSize: 16),
                                    //                   ),
                                    //                   Row(
                                    //                     mainAxisAlignment:
                                    //                         MainAxisAlignment
                                    //                             .spaceBetween,
                                    //                     children: [
                                    //                       const Text(
                                    //                         'Photos',
                                    //                         style: TextStyle(
                                    //                             fontWeight:
                                    //                                 FontWeight
                                    //                                     .w500),
                                    //                       ),
                                    //                       const Text(
                                    //                         '0/4',
                                    //                         style: TextStyle(
                                    //                             fontWeight:
                                    //                                 FontWeight
                                    //                                     .w500),
                                    //                       ),
                                    //                     ],
                                    //                   ),
                                    //                   Container(
                                    //                     height: MediaQuery.of(
                                    //                                 context)
                                    //                             .size
                                    //                             .height *
                                    //                         0.18,
                                    //                     width: MediaQuery.of(
                                    //                             context)
                                    //                         .size
                                    //                         .width,
                                    //                     decoration: BoxDecoration(
                                    //                         color: Colors.white,
                                    //                         border: Border.all(
                                    //                             color: Colors
                                    //                                 .black,
                                    //                             width: 1)),
                                    //                     child: GridView.count(
                                    //                       childAspectRatio:
                                    //                           (1.65 / 3),
                                    //                       shrinkWrap: false,
                                    //                       crossAxisCount: 4,
                                    //                       children:
                                    //                           List.generate(4,
                                    //                               (i) {
                                    //                         return Container(
                                    //                           margin:
                                    //                               const EdgeInsets
                                    //                                   .all(8),
                                    //                           width: 80,
                                    //                           height: 162,
                                    //                           child:
                                    //                               DottedBorder(
                                    //                             padding:
                                    //                                 const EdgeInsets
                                    //                                         .only(
                                    //                                     top: 24,
                                    //                                     left:
                                    //                                         8),
                                    //                             child: Column(
                                    //                                 crossAxisAlignment:
                                    //                                     CrossAxisAlignment
                                    //                                         .center,
                                    //                                 children: [
                                    //                                   const Icon(
                                    //                                       Icons
                                    //                                           .add,
                                    //                                       size:
                                    //                                           32),
                                    //                                   const Text(
                                    //                                     'WAH\nPermit',
                                    //                                     style: TextStyle(
                                    //                                         fontSize:
                                    //                                             12),
                                    //                                     textAlign:
                                    //                                         TextAlign.center,
                                    //                                   )
                                    //                                 ]),
                                    //                             borderType:
                                    //                                 BorderType
                                    //                                     .RRect,
                                    //                             radius: const Radius
                                    //                                 .circular(8),
                                    //                             dashPattern: [
                                    //                               5,
                                    //                               5
                                    //                             ],
                                    //                             color:
                                    //                                 Colors.grey,
                                    //                             strokeWidth: 2,
                                    //                           ),
                                    //                         );
                                    //                       }),
                                    //                     ),
                                    //                   ),
                                    //                 ],
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ),
                                    //       ],
                                    //     ),
                                    //   ],
                                    // )),
                                  }),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 40,
                              width: 326,
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      primary: const Color(0xFF268903)),
                                  onPressed: () {},
                                  child: const Text(
                                    "Apply for Closure",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: Colors.white),
                                  )),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                          ]);
                        } else {
                          return Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            child: CircularProgressIndicator(),
                          );
                        }
                      }),
                ]),
          ),
        ),
      ),
    );
  }

  @override
  void didUpdateWidget(PermitDetailsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if(oldWidget.id != widget.id){

    }
  }
}
