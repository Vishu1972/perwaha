package com.intileo.perwha.perwha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
